var currentSlide = 0;

$(function(){
	initSlides();
});

function initSlides(){
	$('section').eq(currentSlide).addClass('active');
}

function next(){
	goto(currentSlide+1);
}

function back(){
	goto(currentSlide-1);
}

function goto(n){
	if(n > -1 && n < $('section').length) currentSlide = n;
	else return;
	$('section').removeClass('active').eq(currentSlide).addClass('active');
}
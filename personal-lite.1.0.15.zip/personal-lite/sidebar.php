<?php 
/**
* Sidebar template
*
* @package Personal
*/

### Personal theme doesn't support a sidebar. ###
?>
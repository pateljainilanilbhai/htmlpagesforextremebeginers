 jQuery(document).ready(function() {
	jQuery('#menu').slicknav({
	label: '',
	duration: 300,	
	appendTo:'.site-head'
});
});
